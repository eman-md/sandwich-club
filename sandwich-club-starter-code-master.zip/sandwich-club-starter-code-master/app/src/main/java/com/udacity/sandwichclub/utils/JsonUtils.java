package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class JsonUtils {








public static Sandwich parseSandwichJson(String json)
{

   try {
            Sandwich sandwich = new Sandwich();

          JSONObject jsonObject = new JSONObject(json);
          JSONObject jsonObjectName = jsonObject.getJSONObject("name");
          sandwich.setMainName(jsonObjectName.getString("mainName"));
          JSONArray jsonArray = jsonObjectName.getJSONArray("alsoKnownAs");
        if (jsonArray != null) {
            List<String> alsoKnownAsList = new ArrayList<>();
            for (int i = 0; i < jsonArray.length(); i++) {
                alsoKnownAsList.add(jsonArray.getString(i));
            }
            sandwich.setAlsoKnownAs(alsoKnownAsList);
        }
        sandwich.setPlaceOfOrigin(jsonObject.getString("placeOfOrigin"));
        sandwich.setDescription(jsonObject.getString("description"));
        sandwich.setImage(jsonObject.getString("image"));

        JSONArray ingredientsJsonArray = jsonObject.getJSONArray("ingredients");
        if (ingredientsJsonArray != null) {
            List<String> ingredientsList = new ArrayList<>();
            for (int i = 0; i < ingredientsJsonArray.length(); i++) {
                ingredientsList.add(ingredientsJsonArray.getString(i));
            }
            sandwich.setIngredients(ingredientsList);
        }
        return sandwich;
    } catch (JSONException e) {

    }

    return null;
}
}